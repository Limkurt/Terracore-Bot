==================== ACCOUNT ===================
• accounts.txt
    - username, active, posting ng mga account mo
    - format (username:active:posting)

• avoid.txt
    - username ng mga ayaw mo maatake

• alts.txt
    - username ng alts mo
    - pang transfer at pang receive

• main.txt
    - username ng main account mo
    - pang transfer at pang receive

=================== CONFIG ===================
• multiplier.txt
    damage x multiplier = target scrap
    defense x multiplier = target claim

• node.txt
    node sa hive

=================== MODES ===================
• Attack & Claim
    - attack and claim

• Transfer to Main Account
    - transfer SCRAP from alt accounts (alt.txt) to main account (main.txt)

• Transfer to Alt Account
    - transfer SCRAP from main account (main.txt) to alt accounts (alts.txt)